PROJECT NAME

Creator: YOUR NAME
Last updated: 2025-02-14
Path: /home/Desktop/ProjectName/

-----

This folder contains all the data and work done for ProjectName with Collaborator1. ProjectName is to study how deep sea axolotls on have retained their ability to fly. The experiment involved working with captive axolotls and recording their flight. The code is to analyse the biomechanics of their fins in flight. The folders in this project are - 

1) ./Datafiles - Contains large data that cannot be uploaded to GitHub, such as videos, images, audio files or large files >100 MB. Include a file (.XLSX) explaining the details of the big data files. 
2) ./Logistics - A folder for any files related to logistics of the project - invitation letter, official permits, receipts for reimbursement or anything of this kind. Don't include files with personal information, such as passport or bank information.
3) ./Notes - A file containing concise notes that you want to record for collaborators, such as experiment protocol, lab notes, and standard operating protocol (SOPs) for using some methods or software. Use Obsidian or Notion for maintaining your personal notes.
4) ./Presentation - A folder containing the presentation or posters prepared for this project (usually large files not suitable for GitHub repository). Includes a subfolder to organise images and illustrations from the internet.
5) ./project-github-repository/ - 
	5.1) ./Code - A folder with your code (mostly Jupyter notebooks in my case) with a subfolder for functions to be called within the notebooks.
	5.2) ./Data - Usually datafile of .CSV or .HDF5 format <20 MB.
	5.3) ./Manuscript - A folder with the LATEX file to write a paper with your collaborators. Also includes a .bib file to keep track of relevant papers (imported from Zotero).
	5.4) ./Plots - A folder to save your plots, with their names starting from the number of the Jupyter notebook.
6) ./Resources - Files or videos that other people have created and shared with you that can't be distributed widely. Can also contain textbooks, pre-prints, lecture notes from the internet and so on.